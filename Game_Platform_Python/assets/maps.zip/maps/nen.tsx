<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="nen" tilewidth="2046" tileheight="459" tilecount="1" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="nen.png" width="2046" height="459"/>
 </tile>
</tileset>
