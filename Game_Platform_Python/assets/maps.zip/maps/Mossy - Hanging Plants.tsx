<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Mossy - Hanging Plants" tilewidth="512" tileheight="512" tilecount="20" columns="4">
 <image source="Mossy - Hanging Plants.png" width="2048" height="2948"/>
</tileset>
