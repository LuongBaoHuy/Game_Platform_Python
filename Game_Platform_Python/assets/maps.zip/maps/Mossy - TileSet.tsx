<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Mossy - TileSet" tilewidth="512" tileheight="512" tilecount="49" columns="7">
 <image source="Mossy - TileSet.png" width="3584" height="3584"/>
 <tile id="24">
  <objectgroup draworder="index" id="3">
   <object id="3" x="60" y="68" width="384" height="323"/>
  </objectgroup>
 </tile>
 <wangsets>
  <wangset name="nen" type="corner" tile="-1">
   <wangcolor name="" color="#ff0000" tile="-1" probability="1"/>
   <wangtile tileid="0" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="1" wangid="0,0,0,1,0,1,0,0"/>
   <wangtile tileid="2" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="7" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="8" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="9" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="14" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="15" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="16" wangid="0,0,0,0,0,0,0,1"/>
  </wangset>
 </wangsets>
</tileset>
