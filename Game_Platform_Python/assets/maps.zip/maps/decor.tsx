<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="decor" tilewidth="2048" tileheight="2948" tilecount="1" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="Mossy - Hanging Plants.png" width="2048" height="2948"/>
 </tile>
</tileset>
